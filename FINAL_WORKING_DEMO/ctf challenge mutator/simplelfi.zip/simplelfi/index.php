<?php
if (isset($_GET['page'])) {
    $page = $_GET['page'];
    include($page);
} else {
    echo "<h2>Welcome to SecureCorp!</h2>";
    echo "<p>Try adding ?page= to the URL...</p>";
}
?>
